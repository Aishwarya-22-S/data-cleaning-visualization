"""
Data Cleaning & Visualization Project
Thiranex Internship - Task 1
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
import warnings
import os

warnings.filterwarnings("ignore")

# ─────────────────────────────────────────
# 1. GENERATE SAMPLE RAW DATASET
# ─────────────────────────────────────────

np.random.seed(42)
n = 200

raw_data = {
    "CustomerID":    list(range(1001, 1001 + n)),
    "Age":           np.random.randint(18, 70, n).tolist(),
    "Salary":        np.random.normal(50000, 15000, n).round(2).tolist(),
    "Department":    np.random.choice(["HR", "IT", "Finance", "Marketing", "Sales", None], n).tolist(),
    "YearsExp":      np.random.randint(0, 40, n).tolist(),
    "PurchaseAmount":np.random.exponential(200, n).round(2).tolist(),
    "Rating":        np.random.choice([1, 2, 3, 4, 5, None], n).tolist(),
    "City":          np.random.choice(["Mumbai", "Delhi", "Chennai", "Kolkata", "Hyderabad"], n).tolist(),
}

# Inject issues: missing values, duplicates, outliers
df = pd.DataFrame(raw_data)

# Missing values
for col in ["Age", "Salary", "YearsExp", "PurchaseAmount"]:
    idx = np.random.choice(df.index, size=15, replace=False)
    df.loc[idx, col] = np.nan

# Duplicates
duplicates = df.sample(10)
df = pd.concat([df, duplicates], ignore_index=True)

# Outliers
df.loc[5, "Salary"] = 500000
df.loc[10, "PurchaseAmount"] = 9999
df.loc[15, "Age"] = 150

os.makedirs("data", exist_ok=True)
os.makedirs("outputs", exist_ok=True)
df.to_csv("data/raw_dataset.csv", index=False)
print("✅ Raw dataset saved → data/raw_dataset.csv")

# ─────────────────────────────────────────
# 2. DATA CLEANING
# ─────────────────────────────────────────

print("\n📋 BEFORE CLEANING")
print(f"  Shape      : {df.shape}")
print(f"  Duplicates : {df.duplicated().sum()}")
print(f"  Missing    :\n{df.isnull().sum()[df.isnull().sum() > 0].to_string()}")

df_clean = df.copy()

# 2a. Remove duplicates
df_clean.drop_duplicates(inplace=True)

# 2b. Handle outliers using IQR
def remove_outliers_iqr(data, column):
    Q1 = data[column].quantile(0.25)
    Q3 = data[column].quantile(0.75)
    IQR = Q3 - Q1
    lower, upper = Q1 - 1.5 * IQR, Q3 + 1.5 * IQR
    return data[(data[column] >= lower) & (data[column] <= upper)]

for col in ["Salary", "PurchaseAmount", "Age"]:
    df_clean = remove_outliers_iqr(df_clean, col)

# 2c. Fill missing values
df_clean["Age"].fillna(df_clean["Age"].median(), inplace=True)
df_clean["Salary"].fillna(df_clean["Salary"].mean(), inplace=True)
df_clean["YearsExp"].fillna(df_clean["YearsExp"].median(), inplace=True)
df_clean["PurchaseAmount"].fillna(df_clean["PurchaseAmount"].mean(), inplace=True)
df_clean["Department"].fillna("Unknown", inplace=True)
# 2d. Fix data types
df_clean["Age"] = df_clean["Age"].fillna(df_clean["Age"].median()).astype(int)
df_clean["Rating"] = pd.to_numeric(df_clean["Rating"], errors="coerce").fillna(3).astype(int)

df_clean.to_csv("data/cleaned_dataset.csv", index=False)

print("\n✅ AFTER CLEANING")
print(f"  Shape      : {df_clean.shape}")
print(f"  Duplicates : {df_clean.duplicated().sum()}")
print(f"  Missing    : {df_clean.isnull().sum().sum()}")

# ─────────────────────────────────────────
# 3. VISUALIZATIONS
# ─────────────────────────────────────────

palette = sns.color_palette("Set2")
plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "axes.spines.top": False,
    "axes.spines.right": False,
    "figure.dpi": 120,
})

# ── Figure 1: Data Quality Dashboard ────
fig, axes = plt.subplots(1, 3, figsize=(16, 5))
fig.suptitle("Data Quality Report", fontsize=16, fontweight="bold", y=1.02)

# Missing values heatmap
missing = df.isnull().astype(int).head(50)
sns.heatmap(missing.T, cmap="Reds", cbar=False, ax=axes[0],
            yticklabels=True, xticklabels=False)
axes[0].set_title("Missing Values (first 50 rows)", fontweight="bold")
axes[0].set_xlabel("Rows")

# Duplicate count bar
counts = pd.Series({"Before\nCleaning": df.duplicated().sum() + len(df_clean),
                    "After\nCleaning": df_clean.duplicated().sum()})
axes[1].bar(counts.index, counts.values, color=[palette[3], palette[2]], width=0.4)
axes[1].set_title("Duplicate Records", fontweight="bold")
axes[1].set_ylabel("Count")
for i, v in enumerate(counts.values):
    axes[1].text(i, v + 0.2, str(v), ha="center", fontweight="bold")

# Row count comparison
row_counts = pd.Series({"Raw": len(df), "Cleaned": len(df_clean)})
axes[2].bar(row_counts.index, row_counts.values, color=[palette[0], palette[1]], width=0.4)
axes[2].set_title("Dataset Size Comparison", fontweight="bold")
axes[2].set_ylabel("Number of Rows")
for i, v in enumerate(row_counts.values):
    axes[2].text(i, v + 1, str(v), ha="center", fontweight="bold")

plt.tight_layout()
plt.savefig("outputs/01_data_quality_report.png", bbox_inches="tight")
plt.close()
print("\n📊 Saved → outputs/01_data_quality_report.png")

# ── Figure 2: Distribution Analysis ─────
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle("Distribution Analysis (Cleaned Data)", fontsize=15, fontweight="bold")

sns.histplot(df_clean["Age"], kde=True, ax=axes[0, 0], color=palette[0], bins=20)
axes[0, 0].set_title("Age Distribution")

sns.histplot(df_clean["Salary"], kde=True, ax=axes[0, 1], color=palette[1], bins=20)
axes[0, 1].set_title("Salary Distribution")

sns.histplot(df_clean["PurchaseAmount"], kde=True, ax=axes[1, 0], color=palette[2], bins=20)
axes[1, 0].set_title("Purchase Amount Distribution")

rating_counts = df_clean["Rating"].value_counts().sort_index()
axes[1, 1].bar(rating_counts.index.astype(str), rating_counts.values, color=palette[3])
axes[1, 1].set_title("Customer Ratings")
axes[1, 1].set_xlabel("Rating")
axes[1, 1].set_ylabel("Count")

plt.tight_layout()
plt.savefig("outputs/02_distribution_analysis.png", bbox_inches="tight")
plt.close()
print("📊 Saved → outputs/02_distribution_analysis.png")

# ── Figure 3: Department & City Insights ─
fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.suptitle("Department & City Insights", fontsize=15, fontweight="bold")

dept_salary = df_clean.groupby("Department")["Salary"].mean().sort_values()
dept_salary.plot(kind="barh", ax=axes[0], color=palette[:len(dept_salary)])
axes[0].set_title("Average Salary by Department")
axes[0].set_xlabel("Average Salary (₹)")

city_purchase = df_clean.groupby("City")["PurchaseAmount"].sum().sort_values(ascending=False)
axes[1].pie(city_purchase.values, labels=city_purchase.index,
            autopct="%1.1f%%", colors=sns.color_palette("pastel"),
            startangle=140)
axes[1].set_title("Total Purchase Amount by City")

plt.tight_layout()
plt.savefig("outputs/03_department_city_insights.png", bbox_inches="tight")
plt.close()
print("📊 Saved → outputs/03_department_city_insights.png")

# ── Figure 4: Correlation Heatmap ────────
fig, ax = plt.subplots(figsize=(8, 6))
numeric_cols = df_clean.select_dtypes(include=np.number).drop(columns=["CustomerID"])
corr = numeric_cols.corr()
mask = np.triu(np.ones_like(corr, dtype=bool))
sns.heatmap(corr, mask=mask, annot=True, fmt=".2f", cmap="coolwarm",
            ax=ax, square=True, linewidths=0.5)
ax.set_title("Correlation Heatmap", fontsize=14, fontweight="bold")
plt.tight_layout()
plt.savefig("outputs/04_correlation_heatmap.png", bbox_inches="tight")
plt.close()
print("📊 Saved → outputs/04_correlation_heatmap.png")

# ── Figure 5: Boxplot Before vs After ────
fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.suptitle("Outlier Detection: Before vs After Cleaning", fontsize=14, fontweight="bold")

df[["Salary", "PurchaseAmount", "Age"]].plot(kind="box", ax=axes[0],
    patch_artist=True, color=dict(boxes=palette[3], whiskers="gray",
    medians="white", caps="gray"))
axes[0].set_title("Before Cleaning")

df_clean[["Salary", "PurchaseAmount", "Age"]].plot(kind="box", ax=axes[1],
    patch_artist=True, color=dict(boxes=palette[1], whiskers="gray",
    medians="white", caps="gray"))
axes[1].set_title("After Cleaning")

plt.tight_layout()
plt.savefig("outputs/05_outlier_comparison.png", bbox_inches="tight")
plt.close()
print("📊 Saved → outputs/05_outlier_comparison.png")

# ─────────────────────────────────────────
# 4. SUMMARY STATISTICS
# ─────────────────────────────────────────
print("\n" + "="*50)
print("📈 SUMMARY STATISTICS (Cleaned Dataset)")
print("="*50)
print(df_clean.describe().round(2).to_string())
print("\n✅ All tasks completed successfully!")
print("📁 Check the 'outputs/' folder for all visualizations.")
